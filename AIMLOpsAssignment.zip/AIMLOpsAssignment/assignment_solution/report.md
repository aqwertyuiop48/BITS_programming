# Module 05 Technical Report: Productionizing the Product Recommendation Service

**Author:** Platform Engineering  
**Target Platform:** Kubernetes (EKS/GKE) with Horizontal Pod Autoscaling (HPA)  
**Model Stack:** Scikit-Learn / XGBoost Classifier (~50 MB base, ONNX INT8 Quantized)  

---

## 1. Containerization Strategy & Security Justification (20 Marks)

### Base Image Choice
The inference container utilizes `python:3.11-slim-bookworm` (Debian 12 LTS) rather than the standard `python:3.11-slim` or minimal `alpine` variants. 
* **Security & Vulnerability Patching:** Debian Bookworm LTS receives continuous security backports. Using a fixed distribution release avoids floating tag vulnerabilities (such as unfixable base-OS CVEs in Debian Trixie/Testing).
* **Glibc Compatibility:** Unlike `alpine` (which relies on `musl libc`), Debian standardizes on `glibc`. High-performance C-extensions used by ONNX Runtime, NumPy, and SciPy require complex wheel compilation on `musl`, introducing instability and build complexity.

### Multi-Stage Build Trade-offs
The `Dockerfile` splits assembly across two distinct stages:

```dockerfile
# Stage 1: Builder
FROM python:3.11-slim-bookworm AS builder
WORKDIR /build
COPY requirements.txt .
RUN python -m pip install --no-cache-dir --target /deps -r requirements.txt

# Stage 2: Runtime
FROM python:3.11-slim-bookworm AS runtime
...
COPY --from=builder /deps /usr/local/lib/python3.11/site-packages